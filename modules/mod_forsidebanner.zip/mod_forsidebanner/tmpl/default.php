<?php
/**
 * @package     Forside 
 * @subpackage  mod_forsidebanner
 *
 * @copyright   Copyright (C)  2014 Open Source Novasoftware All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.
?>

<div class="newsflash<?php echo $moduleclass_sfx; ?>">
<?php
foreach ($list as $item) :
	require JModuleHelper::getLayoutPath('mod_articles_news', '_item');
endforeach;
?>
</div>
