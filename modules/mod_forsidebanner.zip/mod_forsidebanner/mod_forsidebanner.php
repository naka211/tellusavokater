<?php
/**
 * @package     Forside 
 * @subpackage  mod_forsidebanner
 *
 * @copyright   Copyright (C)  2014 Open Source Novasoftware All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Include the syndicate functions only once
require_once __DIR__ . '/helper.php';
$app  = JFactory::getApplication();
$list = ModArticlesNewsHelper::getList($params);
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require JModuleHelper::getLayoutPath('mod_ forsidebanner', $params->get('layout', 'horizontal'));
