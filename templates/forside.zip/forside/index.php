<?php

defined('_JEXEC') or die;

$doc = JFactory::getDocument();



$doc->addStyleSheet('templates/' . $this->template . '/css/page.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/menu.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/base.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/jquery-ui.css');
$doc->addStyleSheet('templates/' . $this->template . '/css/jquery.fancybox-1.3.4.css');
$doc->addScript('/templates/' . $this->template . '/js/jquery.min.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/jquery-ui.min.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/jquery.easing-1.3.pack.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/jquery.fancybox-1.3.4.pack.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/jquery.mousewheel-3.0.4.pack.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/vah1sbe.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/base.js', 'text/javascript');
$doc->addScript('/templates/' . $this->template . '/js/ga.js', 'text/javascript');
?>
<!DOCTYPE html>
<html>

<head>

    <jdoc:include type="head" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<script type="text/javascript">
    try{Typekit.load();}catch(e){}

    $(function(){
        $("#SubMenu_levelThree ul li ul li:last-child").css("margin-bottom","20px")
    })
</script>
<style type="text/css">
#SubImage {
    background: url('/upload/images/topbilleder/forside.jpg') #fff center center scroll no-repeat;
    margin: 0px;
    padding: 0px;
    -moz-background-size: cover;
    background-size: cover;
    height: 420px;
    /*height: 490px;*/
}
</style>
</head>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title></title>
</head>

<body>
  <div id="TopContent" style="position: relative;">
    <div id="TopGreenBar" style="position: absolute; top: 15px;">
      <div class="wrapper">
        <div class="logo">
         
        </div>

        <div id="TopMenu">
         <jdoc:include type="modules" name="position-0" style="xhtml" />
        </div>
      </div>
    </div>

    <div id="SubImage">
      <div id="ImageRaster"></div>
    </div>
  </div>

  <div id="TemplateContent">
    <div class="wrapper" style="position: relative;">
      <div id="SearchBox" style="top: -75px; left: 695px; background: #fff; width: 240px;">
      <!-- search box -->
      <jdoc:include type="modules" name="searchbox" style="xhtml" />
      </div>

      <div id="NewsContainer">
      <!-- NewsContainer modules -->
        <h2>Seneste nyt fra <span style="color: #548b3e;">TELLUS</span></h2>

        <p>&nbsp;</p>
        <jdoc:include type="modules" name="position-1" style="xhtml" />
      </div>

      <div id="AboutUsText">
      <!-- about us modules -->
        <jdoc:include type="modules" name="position-2" style="xhtml" />
      </div>

      <div id="VideoAndNewsletter">
        <!-- <div class="Video"><a href="http://vimeo.com/moogaloop.swf?clip_id=38420222&amp;autoplay=1" class="mooga"><img src="/static/images/video_img.png" alt="Se filmen her" /></a></div> -->
        <!-- <div id="NewsLetter"><img src="/static/images/tellus_newsletter.png" alt="Nyhedsbrev" /></div>
                <div class="shortcuts" style="margin-left: 15px; position: absolute; bottom: -290px;"> -->

        <div class="shortcuts" style="margin-left: 15px; margin-top: 10px;">
          <a href="./Forside_files/Forside.htm" onclick="SubscribeNewsLetter()" class="jquery-button">- Tilmeld nyhedsbrev</a> <!-- <a href="#" class="jquery-button">- Se seneste nyhedsbrev</a> -->
           <a href="./Forside_files/Forside.htm" onclick="DownloadFolders()" class="jquery-button">- Download pjecer her</a>
        </div>
      </div>

      <div class="bottom_bg" style="clear: both;"></div>
    </div>
  </div>

  <div id="BottomContent">
    <div class="wrapper">
      <div class="inner_wrapper" style="width: 670px!important;">
        <div class="logo" style="float: left; position: relative; top: -18px;">
          <a href="http://www.tellusadvokater.dk/">
          <img src="./Forside_files/tellus_mini_logo.png" alt="Tellus Advokater" />
          </a>
        </div>

        <div class="adress" style="float: left;">
          <p>Majsmarken 1, 7190 Billund</p>

          <p>Tlf: 76 60 23 30</p>

          <p>Email: <a href="mailto:tellus@tellusadvokater.dk">tellus@tellusadvokater.dk</a></p>
        </div>

        <div class="adress" style="float: left;">
          <p>John Tranums Vej 25, 6705 Esbjerg ?</p>

          <p>Tlf: 76 60 23 30</p>

          <p>Email: <a href="mailto:tellus@tellusadvokater.dk">tellus@tellusadvokater.dk</a></p>
        </div>

        <div class="adress" style="float: left; margin-top: 26px; margin-left:36px!important; font-size: 15px; color: #54890E;">
          <i><b>Jura p? jysk</b></i>
        </div>
      </div>

      <div id="WhatWeAre" style="clear: both; letter-spacing: 3px; font-size: 12px; color: #999; height: 20px; text-align: center; width: 960px;">
        Advokatanpartsselskab
      </div>
    </div>
  </div>
  <script type="text/javascript">
//<![CDATA[
  $(document).ready(function() {
    $("#NewsLetterContainer input[type=text]").focus(function() {

        if($(this).val() == $(this).get(0).defaultValue)
        {
            $(this).val("");
        }

    }).blur(function() {

        if($(this).val() == "")
        {
            $(this).val( $(this).get(0).defaultValue );
        }

    });
  });
  //]]>
  </script><!-- DOWNLOAD FOLDERS -->

  <div id="DownloadContainer" title="Download pjecer" style="display:none;">
    Her kan du downloade vores pjecer.

    <ul>
      <li><a href="http://www.tellusadvokater.dk/upload/files/TELLUSAdvokater.pdf" target="_blank">TELLUS Advokater - Jura p? jysk</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/fb14.pdf" target="_blank">Forretningsbetingelser</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/testamente%202013%206%20sider.pdf" target="_blank">Testamenter</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/familie%20og%20arveret%202013.pdf" target="_blank">Familie- og arveret</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/ps14.pdf" target="_blank">Privat skifte</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/selskaber.pdf" target="_blank">Selskabsdannelse</a></li>

      <li><a href="http://www.tellusadvokater.dk/upload/files/pdf/bestyrelse.pdf" target="_blank">Bestyrelse - S?dan</a></li>
    </ul>
  </div>

  <div id="fancybox-tmp"></div>

  <div id="fancybox-loading"></div>

  <div id="fancybox-overlay"></div>

  <div id="fancybox-wrap">
    <div id="fancybox-outer">
      <div class="fancybox-bg" id="fancybox-bg-n"></div>

      <div class="fancybox-bg" id="fancybox-bg-ne"></div>

      <div class="fancybox-bg" id="fancybox-bg-e"></div>

      <div class="fancybox-bg" id="fancybox-bg-se"></div>

      <div class="fancybox-bg" id="fancybox-bg-s"></div>

      <div class="fancybox-bg" id="fancybox-bg-sw"></div>

      <div class="fancybox-bg" id="fancybox-bg-w"></div>

      <div class="fancybox-bg" id="fancybox-bg-nw"></div>

      <div id="fancybox-content"></div><a id="fancybox-close"></a>

      <div id="fancybox-title"></div><a href="javascript:;" id="fancybox-left"><span class="fancy-ico" id="fancybox-left-ico"></span></a><a href="javascript:;" id="fancybox-right"><span class="fancy-ico" id="fancybox-right-ico"></span></a>
    </div>
  </div>

  <div class="ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable" tabindex="-1" role="dialog" aria-labelledby="ui-dialog-title-NewsLetterContainer" style="display: none; z-index: 1002; outline: 0px; height: auto; width: 300px; top: 537px; left: 520.5px;">
    <div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">
      <span class="ui-dialog-title" id="ui-dialog-title-NewsLetterContainer">Tilmeld nyhedsbrev</span><a href="./Forside_files/Forside.htm" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick">close</span></a>
    </div>

    <div id="NewsLetterContainer" style="width: auto; min-height: 36.71875px; height: auto;" class="ui-dialog-content ui-widget-content" scrolltop="0" scrollleft="0">
      <form action="http://www.tellusadvokater.dk/modules/news/subscribe-email.php" method="post" id="signupform_form">
        <table border="0" cellpadding="2" cellspacing="2">
          <tbody>
            <tr>
              <td>Indtast dit navn her:</td>
            </tr>

            <tr>
              <td><input type="text" name="name" id="signupform_name" value="Navn" class="std" style="margin-bottom:8px; height: 28px; pading-left: 5px;" /></td>
            </tr>

            <tr>
              <td>Og din email her:</td>
            </tr>

            <tr>
              <td><input type="text" name="email" id="signupform_email" value="E-mail" class="std" style="margin-bottom:8px; height: 28px; pading-left: 5px;" /></td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>

    <div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix">
      <div class="ui-dialog-buttonset">
        <button type="button" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false"><span class="ui-button-text">Tilmeld</span></button>
      </div>
    </div>
  </div>


</body>




</html>



